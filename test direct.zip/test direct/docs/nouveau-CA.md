# Nouveau CA

Ce document décrit les actions à effectuer pour mettre à jour la visualisation publique.

1. Mettre le fichier xml du nouveau CA dans `data/finances/CA`

S'assurer que ce dossier ne contient que les CA que l'on souhaite afficher