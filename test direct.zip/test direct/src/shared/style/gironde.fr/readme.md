Dans ce dossier sont des feuilles CSS qui sont des copies non-modifiées des styles que l'on peut trouver publiquement sur le site gironde.fr.

Ils ont vocation à être utilisé à des desseins de test pour la version démo et s'apercevoir au plus vite de différences avec l'intégration dans le vrai site gironde.fr.

Sur le site en production, les liens vers les feuilles de style semblent être générés dynamiquement par le CMS. Ceci empêche l'idée de *hotlinker* le style, d'où la duplication