export const HOME = 'HOME';

export const SOLIDARITES = 'SOLIDARITES';
export const INVEST = 'INVEST';
export const PRESENCE = 'PRESENCE';

export { DF, RF, DI, RI } from '../../../shared/js/finance/constants';