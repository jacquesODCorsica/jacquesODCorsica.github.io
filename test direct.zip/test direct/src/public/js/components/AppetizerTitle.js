import PageTitle from '../../../shared/js/components/gironde.fr/PageTitle';
export default PageTitle;