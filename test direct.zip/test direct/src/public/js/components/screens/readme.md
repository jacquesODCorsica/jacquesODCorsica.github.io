# Screen

What is called "screen" here is a top-level React component