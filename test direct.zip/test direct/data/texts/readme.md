Here are all the texts that are aimed to be used in the public dataviz

